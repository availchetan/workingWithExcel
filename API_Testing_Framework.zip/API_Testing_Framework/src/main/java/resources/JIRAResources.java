package resources;

public class JIRAResources
{

	public static String Res1()
	{
		String creproj="/rest/api/2/project";
		
		return creproj;
		
	}
	
	
	
}
